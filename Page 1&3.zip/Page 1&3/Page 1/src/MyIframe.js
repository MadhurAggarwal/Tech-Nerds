import Iframe from 'react-iframe';
<Iframe 
url="https://maps.google.com/maps?q=Tangesir%20Dates%20Products&amp;t=&amp;z=13&amp;ie=UTF8&amp;iwloc=&amp;output=embed" 
width="300px"
height="150"
 allowfullscreen />